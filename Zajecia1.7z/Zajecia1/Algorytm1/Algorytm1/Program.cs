﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algorytm1
{
    class Program
    {
        public static int[] p;
        public static int[] r;
        public static int q;

        static void Main(string[] args)
        {
            Random rand = new Random();
            Console.WriteLine("Podaj wielkosc tablicy:");
            int size = Convert.ToInt32(Console.ReadLine());
            p = new int[size];
            r = new int[size];

            for(int i = 0; i < size; i++)
            {
                
                //Console.WriteLine($"Podaj wartosc {i + 1}:");
                p[i] = rand.Next(1, 50);
                r[i] = -1;
            }

            Console.WriteLine($"Podane wartosci:");

            for (int i = 0; i < size; i++)
            {
                Console.Write($"{p[i]} ");
            }

            q = 0;
            Console.WriteLine();
            Console.WriteLine($"Wynik: {Calculate(size - 1)}");
            Console.WriteLine($"Wynik: {Calculate2(size - 1)}");

            Console.ReadKey();
        }

        private static int Calculate(int n)
        {
            n = n - 1;

            int q;

            if(r[n] != -1)
            {
                return r[n];
            }

            q = p[n];

            for(int i = 0; i < n; i++)
            {
                q = Math.Max(q, Calculate(n - i) + p[i]);
            }

            r[n] = q;

            return q;
        }

        private static int Calculate2(int n)
        {            
            for (int j = 2; j <= n; j++)
            {
                r[j] = p[j];

                for (int i = 0; i <= j - 1; i++)
                {
                    r[j] = Math.Max(r[j], p[i] + r[j - i]);
                }

            }

            return r[n];
        }
    }
}
